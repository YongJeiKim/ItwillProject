
/* --- 채팅방 생성 --- */
insert into chat_room(c_room_no,from_id,to_id,p_no) values(CHAT_ROOM_C_ROOM_NO_SEQ.nextval,'carrot6','carrot1',1);
insert into chat_room(c_room_no,from_id,to_id,p_no) values(CHAT_ROOM_C_ROOM_NO_SEQ.nextval,'carrot2','carrot4',2);
insert into chat_room(c_room_no,from_id,to_id,p_no) values(CHAT_ROOM_C_ROOM_NO_SEQ.nextval,'carrot2','carrot3',3);













