package com.itwill.brown_carrot_market.mapper;

public interface PaymentMapper {

}
