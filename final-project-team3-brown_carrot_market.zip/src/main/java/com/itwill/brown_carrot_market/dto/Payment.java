package com.itwill.brown_carrot_market.dto;

public class Payment {

}
