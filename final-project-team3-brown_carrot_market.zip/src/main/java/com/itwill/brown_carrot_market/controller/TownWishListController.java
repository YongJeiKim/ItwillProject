package com.itwill.brown_carrot_market.controller;

public class TownWishListController {

}
