package com.itwill.brown_carrot_market.service;

public class ReviewServiceImpl {

}
